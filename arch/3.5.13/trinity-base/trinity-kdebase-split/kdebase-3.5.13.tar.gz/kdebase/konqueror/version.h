#ifndef _VERSION_H
#define KONQUEROR_VERSION "3.5.10"
#endif
