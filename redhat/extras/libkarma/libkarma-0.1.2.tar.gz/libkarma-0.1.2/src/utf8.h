/*
 * libkarma/utf8.h
 *
 * Copyright (c) Frank Zschockelt <libkarma@freakysoft.de> 2004
 *
 * You may distribute and modify this program under the terms of 
 * the GNU GPL, version 2 or later.
 *
 */

#ifndef _UTF8_H
#define _UTF8_H

#endif /* _UTF8_H */
